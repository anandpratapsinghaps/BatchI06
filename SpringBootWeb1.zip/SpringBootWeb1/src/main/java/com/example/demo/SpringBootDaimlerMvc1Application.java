package com.example.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootDaimlerMvc1Application 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(SpringBootDaimlerMvc1Application.class, args);
	}
}

//create table employee1(name varchar(30),phoneno varchar(30),
		//email varchar(30),address varchar(30),salary varchar(30),design varchar(30));
package com.example.demo;
import java.util.List;
public interface IBookService 
{
public void addBook(Book book);
public void editBook(Book book,int bookid);
public boolean deleteBook(int bookid);
public Book getBookById(int bookid);
public List<Book> getAllBook();

}

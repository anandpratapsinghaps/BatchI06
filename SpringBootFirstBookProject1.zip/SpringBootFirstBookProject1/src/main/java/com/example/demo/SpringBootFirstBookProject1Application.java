package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFirstBookProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFirstBookProject1Application.class, args);
	}

}

<%@page import="java.util.Date"%>
<html>
<body>
<%
Date d = new Date();
out.println(d);
response.addHeader("Refresh", "1");
%>
</body>
</html>

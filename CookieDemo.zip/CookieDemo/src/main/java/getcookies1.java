import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/getcookies1")
public class getcookies1 extends HttpServlet {

    public void service(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
          response.setContentType("text/html");
          PrintWriter out = response.getWriter();
         try {
      
            out.println("<html>"); 
            
            out.println("<head>");
            out.println("<title>Servlet getcookies</title>");            
            out.println("</head>");
            out.println("<body bgcolor='blue'>");
            out.println("<h1>Servlet getcookies at " + request.getContextPath() + "</h1>");
                  Cookie[] cookies=request.getCookies();
            for(int i=0;i<cookies.length;i++)
            {
                String name=cookies[i].getName();
                String value=cookies[i].getValue();
                response.addCookie(cookies[i]);
                out.println("<br> cookie name="+name+"<br>");
                out.println("<br> cookie value="+value);
            }
            out.println("</body>");
            out.println("</html>");
        
          } finally {               
               out.close();
          }
     }
}
